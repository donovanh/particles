require('./builder.js').build({
   "baseUrl": "../src/",
   "main": "dat/color/Color",
   "out": "../build/dat.color.js",
   "minify": false,
   "shortcut": "dat.Color",
   "paths": {}
});